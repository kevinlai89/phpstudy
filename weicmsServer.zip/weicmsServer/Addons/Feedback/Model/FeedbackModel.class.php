<?php

namespace Addons\Feedback\Model;
use Think\Model;

/**
 * Feedback模型
 */
class FeedbackModel extends Model{

}
