<?php

namespace Common\Model;

use Think\Model;

/**
 * 计数池
 */
class PlanTaskModel extends Model {
	function run() {
	}
}
?>
