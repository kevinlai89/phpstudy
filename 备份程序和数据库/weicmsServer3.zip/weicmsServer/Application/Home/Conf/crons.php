<?php
return array(
	'custom' => array('custom', 60), //这里的意思是每隔60秒，执行一次recommend.php文件
);